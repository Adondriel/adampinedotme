var app = angular.module( 'myApp', [] )
.controller('myController', ['$scope', '$http', function($scope, $http) {
	$scope.petData = null;
    $http({
                    method: 'GET',
                    url: 'http://api.petfinder.com/shelter.getPets?format=json&id=PA302&key=22a4dfb985faaf903009ae84e157f24a'
                }).then(function successCallback(response) {
                    //console.log(response);
                    $scope.petData = response.data.petfinder;
                    console.log($scope.petData);
    }, function errorCallback(response) {
                    $scope.petData = null;
                });
}])
.config( [
    '$compileProvider',
    function( $compileProvider )
    {   
        $compileProvider.aHrefSanitizationWhitelist(/^\s*(https?|ftp|mailto|chrome-extension|mumble):/);
        // Angular before v1.2 uses $compileProvider.urlSanitizationWhitelist(...)
    }
]);